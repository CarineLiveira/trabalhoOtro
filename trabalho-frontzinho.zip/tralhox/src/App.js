import React from 'react';
import './App.css';
import Home from './pages/Home';
// import Routes from './pages/routers/Routers';

function App() {
  return (
    <div className="App">
      <div className="header">
        <h3>POKEDEX</h3>
      </div>
      <Home />
    </div>

    
  );
}

export default App;
