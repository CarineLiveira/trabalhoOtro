import React from 'react';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Sobre from './pages/Sobre';

const App = () => {
  return (
    <Router>
      <div>
        <header className="cabecalho">
          <section>
            <nav className="cabecalho_menu">
              <Link to="/" className="cabecalho_menu_link">Home</Link>
              <Link to="/portifolio" className="cabecalho_menu_link">Portifolio</Link>
              <Link to="/sobre" className="cabecalho_menu_link">Sobre</Link>
              <Link to="/contato" className="cabecalho_menu_link">Contato</Link>
            </nav>
          </section>
        </header>

        <main>
          <Route exact path="/" component={Home} />
          <Route path="/sobre" component={Sobre} />
        </main>
      </div>
    </Router>
  );
};

export default App;
