import { Container } from "@mui/material";
import PokemonCard from "../componets/PokemonCard";
import { Grid } from "@mui/material";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { useHistory } from 'react-router-dom';

const Home = () => {
  const [pokemons, setPokemons] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 12;

  useEffect(() => {
    getPokemons();
  }, []);

  const getPokemons = () => {
    var endPoints = [];
    for (var i = 1; i <= 60; i++) {
      endPoints.push(`https://pokeapi.co/api/v2/pokemon/${i}/`);
    }
    console.log(endPoints);
    axios
      .all(endPoints.map((endPoint) => axios.get(endPoint)))
      .then((res) => setPokemons(res));
  };

  const handlePreviousPage = () => {
    setCurrentPage((prevPage) => prevPage - 1);
  };

  const handleNextPage = () => {
    setCurrentPage((prevPage) => prevPage + 1);
  };

  const getPokemonsForCurrentPage = () => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return pokemons.slice(startIndex, endIndex);
  };

  const totalPages = Math.ceil(pokemons.length / itemsPerPage);
  const currentPokemons = getPokemonsForCurrentPage();

  const history = useHistory(); 

  const handleNavigateToSobrePage = () => {
    history.push("/sobre"); 
  };

  return (
    <div>
      <Container maxWidth="">
        <Grid container>
          {currentPokemons.map((pokemon, key, types) => (
            <Grid item xs={2} key={key}>
              <PokemonCard
                name={pokemon.data.name}
                image={pokemon.data.sprites.front_default}
                types={pokemon.data.types}
              />
            </Grid>
          ))}
        </Grid>

        <div>
          <button disabled={currentPage === 1} onClick={handlePreviousPage}>
            Anterior
          </button>
          <button disabled={currentPage === totalPages} onClick={handleNextPage}>
            Próxima
          </button>

         
          <button onClick={handleNavigateToSobrePage}>
            Ir para Sobre
          </button>
        </div>
      </Container>
    </div>
  );
};

export default Home;
